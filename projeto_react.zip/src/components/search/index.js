import React from "react";

export default function Search() {
  return (
    <form action="">
      <input type="search" name="" id="" />
      <button type="submit">Pesquisa</button>
    </form>
  );
}
